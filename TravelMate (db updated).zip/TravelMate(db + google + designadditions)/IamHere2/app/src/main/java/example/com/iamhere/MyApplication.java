package example.com.iamhere;

import android.app.Application;
import android.content.res.Configuration;

/**
 * Created by 40080429 on 20/04/2016.
 */
public class MyApplication extends Application {
    private static MyApplication singleton;
    EntrySQLiteHelper db = new EntrySQLiteHelper(this);

    public MyApplication getInstance(){
        return singleton;
    }
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        singleton = this;
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }

    public EntrySQLiteHelper getDatabase(){
        return this.db;
    }
}