package example.com.iamhere;

import android.app.Activity;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by 40080429 on 14/04/2016.
 */
public class EntryActivity extends Activity {

    TextView date;
    TextView mood;
    EditText entryTitle2, entry2;
    Entry selectedEntry;
    EntrySQLiteHelper db;
    public int id;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        MyApplication mApplication = (MyApplication)getApplicationContext();
        db = mApplication.db;

        setContentView(R.layout.activity_entry);

        date = (TextView) findViewById(R.id.displaydate);
        mood = (TextView) findViewById(R.id.displaymood);
        entryTitle2 = (EditText) findViewById(R.id.titleEdit);
        entry2 = (EditText) findViewById(R.id.entryEdit);
        // get the intent that we have passed from AndroidDatabaseExample

        String id2;
        Bundle extras = getIntent().getExtras();

        if(extras != null) {
            id2 = extras.getString("entry");
            id = Integer.parseInt(id2);
            //   String id = intent.get("entry", -1);
        }


        // open the database of the application context

        // read the entry with "id" from the database
        // call method from my_journals.java to get id

        //id=1;
        selectedEntry = db.readEntry(id);
        initializeViews();
    }
    public void initializeViews() {
        entryTitle2.setText(selectedEntry.getEntryTitle());
        entry2.setText(selectedEntry.getEntry());
        date.setText(selectedEntry.getEntryDate());
        mood.setText(selectedEntry.getEntryMood());

    }
    public void update(View v) {
        Toast.makeText(getApplicationContext(), "This entry is updated.",
                Toast.LENGTH_SHORT).show();
        selectedEntry.setEntryTitle(((EditText)
                findViewById(R.id.titleEdit)).getText().toString());
        selectedEntry.setEntry(((EditText)
                findViewById(R.id.entryEdit)).getText().toString());

        // update
        Intent intentmenu = new Intent(this, my_journals.class);
        startActivity(intentmenu);
        db.updateEntry(selectedEntry);
        finish();
    }
    public void delete(View v) {
        Toast.makeText(getApplicationContext(), "This entry is deleted.",
                Toast.LENGTH_SHORT).show();
        // delete
        Intent intentmenu = new Intent(this, my_journals.class);
        startActivity(intentmenu);
        db.deleteEntry(selectedEntry);
        finish();

    }



}
