package example.com.iamhere;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 40059110 on 08/04/2016.
 */
public class my_journals extends ListActivity implements AdapterView.OnItemClickListener {

    EntrySQLiteHelper db;
    List<Entry> list;
    List<String> listTitle;
    ArrayAdapter myAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MyApplication mApplication = (MyApplication) getApplicationContext();
        db = mApplication.db;
        setContentView(R.layout.my_journals);


        list = db.getAllEntries();

        List<String> listTitle = new ArrayList<String>();

        for (int i = 0; i < db.getAllEntries().size(); i++) {
            listTitle.add(i, list.get(i).getEntryTitle());
        }

        myAdapter = new ArrayAdapter(this, R.layout.row_layout, R.id.listText,
                listTitle);

        getListView().setOnItemClickListener(this);

        setListAdapter(myAdapter);



    }


    //  public void onItemClick(ListView l, View v, int position, long id) {

    // display position

    //  }


    // put this into a method and call it in EntryActivity.java
    @Override
    public void onItemClick(AdapterView arg0, View arg1, int arg2, long arg3) {

        Intent intent = new Intent(this, EntryActivity.class);
        long id = list.get(arg2).getId();
        String idStr = String.valueOf(id);
        intent.putExtra("entry", idStr);
        //  intent.putExtra("entry", arg2);
        //startActivityForResult(intent, 1);
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // get all books again, because something changed
        list = db.getAllEntries();
        List<String> listTitle = new ArrayList<String>();
        for (int i = 0; i < list.size(); i++) {
            listTitle.add(i, list.get(i).getEntryTitle());
        }
        myAdapter = new ArrayAdapter(this, R.layout.row_layout, R.id.listText,
                listTitle);
        getListView().setOnItemClickListener(this);
        setListAdapter(myAdapter);
    }
}

