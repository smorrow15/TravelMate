package example.com.iamhere;

import android.os.Bundle;

/**
 * Created by 40059110 on 08/04/2016.
 */
public class settings extends activity2 {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings);


    }


}
