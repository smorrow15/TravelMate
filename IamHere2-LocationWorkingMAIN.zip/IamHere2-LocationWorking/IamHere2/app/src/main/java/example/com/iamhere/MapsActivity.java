package example.com.iamhere;

import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {
 private GoogleMap mMap;
 private ArrayList<MyMarker> mMyMarkersArray = new ArrayList<MyMarker>();
 private HashMap<Marker, MyMarker> mMarkersHashMap;
 List<Entry> list;
 EntrySQLiteHelper db;
 @Override
 protected void onCreate(Bundle savedInstanceState) {
 super.onCreate(savedInstanceState);
 setContentView(R.layout.activity_maps);
 ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
 .getMapAsync(this);

 mMarkersHashMap = new HashMap<Marker, MyMarker>();
 //add coordinates to the HashMap
  MyApplication mApplication = (MyApplication)getApplicationContext();
  db = mApplication.db;

 list = db.getAllEntries();

  for (int i = 0; i < db.getAllEntries().size(); i++) {
   String lat = list.get(i).getEntryLocationLat();
   String lon = list.get(i).getEntryLocationLon();
   String icon;
   mMyMarkersArray.add(new MyMarker("Atlantic Ocean", "icondefault",
           Double.parseDouble(lon), Double.parseDouble(lat)));

  }
 }
 @Override
 public void onMapReady(GoogleMap googleMap) {
 mMap = googleMap;
 setUpMap();
 }
 /**
 * This is where we can add markers or lines, add listeners or move the camera. In
this case, we
 * just add a marker near Africa.
 * <p/>
 * This should only be called once.
 */
 private void setUpMap() {
 mMap.addMarker(new MarkerOptions().position(new LatLng(0, 0)).title("Marker"));
 try {
 mMap.setMyLocationEnabled(true);
 }
 catch(SecurityException e)
 {
 e.printStackTrace();
 }
 plotMarkers(mMyMarkersArray);
 }
 private void plotMarkers(ArrayList<MyMarker> markers)
 {
  // if anything in array
 if(markers.size() > 0)
 {
  // or each item in array
 for (MyMarker myMarker : markers)
 {
 // Create user marker with custom icon and other options
 MarkerOptions markerOption = new MarkerOptions().position(new
         // draw lat and long values
         LatLng(myMarker.getmLatitude(), myMarker.getmLongitude()));
//



markerOption.icon(BitmapDescriptorFactory.fromResource(R.drawable.currentlocation_icon));
 Marker currentMarker = mMap.addMarker(markerOption);
 mMarkersHashMap.put(currentMarker, myMarker);
 mMap.setInfoWindowAdapter(new MarkerInfoWindowAdapter());
 }
 }
 }

  private int manageMarkerIcon(String markerIcon)
  {
      if (markerIcon.equals("icon1"))
      return R.drawable.icon1;
      else if(markerIcon.equals("icon2"))
      return R.drawable.icon2;
      else if(markerIcon.equals("icon3"))
      return R.drawable.icon3;
      else if(markerIcon.equals("icon4"))
      return R.drawable.icon4;
      else if(markerIcon.equals("icon5"))
      return R.drawable.icon5;
      else if(markerIcon.equals("icon6"))
      return R.drawable.icon6;
      else if(markerIcon.equals("icon7"))
      return R.drawable.icon7;
      else
      return R.drawable.icondefault;
  }
 public class MarkerInfoWindowAdapter implements GoogleMap.InfoWindowAdapter
 {
 public MarkerInfoWindowAdapter()
 {
 }
 @Override
 public View getInfoWindow(Marker marker)
 {
 return null;
 }
 @Override
 public View getInfoContents(Marker marker)
 {
 View v = getLayoutInflater().inflate(R.layout.infowindow_layout, null);
 MyMarker myMarker = mMarkersHashMap.get(marker);
 ImageView markerIcon = (ImageView) v.findViewById(R.id.marker_icon);
 TextView markerLabel = (TextView)v.findViewById(R.id.marker_label);
 TextView anotherLabel = (TextView)v.findViewById(R.id.another_label);
 markerIcon.setImageResource(manageMarkerIcon(myMarker.getmIcon()));
 markerLabel.setText(myMarker.getmLabel());
 anotherLabel.setText("A custom text");
 return v;
 }
 }
}