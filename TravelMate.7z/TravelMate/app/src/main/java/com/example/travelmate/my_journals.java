package com.example.travelmate;

import android.os.Bundle;

/**
 * Created by 40059110 on 08/04/2016.
 */
public class my_journals extends activity2 {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_journals);


    }
}
