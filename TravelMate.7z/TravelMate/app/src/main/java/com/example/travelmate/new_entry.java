package com.example.travelmate;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Date;

public class new_entry extends activity2{

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_entry);

    //    String currentDateTimeString = DateFormat.getDateTimeInstance().format(new Date());

        // textView is the TextView view that should display it
  //      textView.setText(currentDateTimeString);
    }




}
