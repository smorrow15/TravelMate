package example.com.iamhere;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.DatePicker;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class new_entry extends activity2 implements AccelerometerListener{

    private DatePicker datePicker;
    private Calendar calendar;
    private TextView dateView;
    private int year, month, day;
    private EditText title, entry;
    private Button SaveButton;
    EntrySQLiteHelper db;
    private SeekBar mood;
    private TextView MText;

    private Button btnSave;
    private TextView locationinfo;
    private ImageButton happy, sad;

    private static final long ONE_MIN = 1000 * 60;
    private static final long TWO_MIN = ONE_MIN * 2;
    private static final long FIVE_MIN = ONE_MIN * 5;
    private static final long MEASURE_TIME = 1000 * 30;
    private static final long POLLING_FREQ = 1000 * 10;
    private static final float MIN_ACCURACY = 25.0f;
    private static final float MIN_LAST_READ_ACCURACY = 500.0f;
    private static final float MIN_DISTANCE = 10.0f;
    public Double latdbl;
    public Double longdbl;
    public String latstr;
    public String longstr;

    Button btnShowLocation;

    // Current best location estimate
    private Location mBestReading;
    // Reference to the LocationManager and LocationListener
    private LocationManager mLocationManager;
    private LocationListener mLocationListener;
    private final String TAG = "new_entry";
    private boolean mFirstUpdate = true;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_entry);






        title = (EditText) findViewById(R.id.etJourTitle);
        entry = (EditText) findViewById(R.id.etJourDescription);
        SaveButton = (Button) findViewById(R.id.save);
        dateView = (TextView) findViewById(R.id.datepickertext);
        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        locationinfo = (TextView) findViewById(R.id.locationinfo);
        MText = (TextView)findViewById(R.id.MText2);
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        showDate(year, month + 1, day);
        locationinfo = (TextView) findViewById(R.id.locationinfo);
        MyApplication mApplication = (MyApplication)getApplicationContext();
        db = mApplication.db;
        addListenerOnButton();
        latdbl = 0.00;
        longdbl = 0.00;
        latstr = String.valueOf(latdbl);
        longstr = String.valueOf(longdbl);
        locationinfo.setVisibility(View.INVISIBLE);


        SaveButton.setOnClickListener(new View.OnClickListener() {
                                          @Override
                                          public void onClick(View v) {

                                              String entrytitle = title.getText().toString();
                                              String insertentry = entry.getText().toString();
                                              String insertdate = dateView.getText().toString();
                                              String insertmood = MText.getText().toString();
                                              String insertlat = latstr;
                                              String insertlon = longstr;

                                              db.createEntry(entrytitle, insertentry, insertdate, insertmood, insertlat, insertlon);
                                              title.setText("");
                                              entry.setText("");
                                              Toast.makeText(getApplicationContext(), "New entry successfully added", Toast.LENGTH_SHORT).show();

                                              db.close();
                                              List<Entry> list=db.getAllEntries();
                                              Intent intentmenu = new Intent(new_entry.this, my_journals.class);
                                              startActivity(intentmenu);
                                          }
                                      }
        );






        boolean permissionGranted = ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if(permissionGranted) {
            // {Some Code}
        } else {
            ActivityCompat.requestPermissions(this, new
                    String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 200);
        }


        // Acquire reference to the LocationManager
        if (null == (mLocationManager = (LocationManager)
                getSystemService(Context.LOCATION_SERVICE)))
            finish();
        // Get best last location measurement
        mBestReading = bestLastKnownLocation(MIN_LAST_READ_ACCURACY, FIVE_MIN);
        // Display last reading information
        if (null != mBestReading) {
            updateDisplay(mBestReading);
        } else {
            locationinfo.setText("No Location Reading");
        }
        mLocationListener = new LocationListener() {
            // Called back when location changes


            public void onLocationChanged(Location location) {

                // Determine whether new location is better than current best
                // estimate
                if (null == mBestReading
                        || location.getAccuracy() < mBestReading.getAccuracy()) {
                    // Update best estimate
                    mBestReading = location;
                    // Update display
                    updateDisplay(location);
                    if (mBestReading.getAccuracy() < MIN_ACCURACY)
                        try {
                            mLocationManager.removeUpdates(mLocationListener);
                        }
                        catch (SecurityException se){
                            se.printStackTrace();
                        }
                }
            }
            public void onStatusChanged(String provider, int status,
                                        Bundle extras) {
                // NA
            }
            public void onProviderEnabled(String provider) {
                // NA
            }
            public void onProviderDisabled(String provider) {
                // NA
            }
        };



    }

    @SuppressWarnings("deprecation")
    public void setDate(View view) {
        showDialog(999);

    }

    // shows today's date
    private void showDate(int year, int month, int day) {
        dateView.setText(new StringBuilder().append(day).append("/")
                .append(month).append("/").append(year));
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 999) {
            return new DatePickerDialog(this, myDateListener, year, month, day);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker arg0, int arg1, int arg2, int arg3) {
            // TODO Auto-generated method stub
            // arg1 = year
            // arg2 = month
            // arg3 = day
            showDate(arg1, arg2+1, arg3);
        }
    };

    public void onShake(float force) {

        // Do your stuff here

        EditText clear =(EditText) findViewById(R.id.etJourDescription);
        clear.setText("");

        // Called When Motion Detected


    }

    @Override
    public void onResume() {
        super.onResume();


        //Check device supported Accelerometer senssor or not
        if (AccelerometerManager.isSupported(this)) {

            //Start Accelerometer Listening
            AccelerometerManager.startListening(this);
        }

        // Determine whether initial reading is
        // "good enough". If not, register for
        // further location updates
        if (null == mBestReading
                || mBestReading.getAccuracy() > MIN_LAST_READ_ACCURACY
                || mBestReading.getTime() < System.currentTimeMillis()
                - TWO_MIN) {
            // Register for network location updates
            try {
                if (null != mLocationManager
                        .getProvider(LocationManager.NETWORK_PROVIDER)) {
                    mLocationManager.requestLocationUpdates(
                            LocationManager.NETWORK_PROVIDER, POLLING_FREQ,
                            MIN_DISTANCE, mLocationListener);
                }
            }
            catch(SecurityException se)
            {
                se.printStackTrace();
            }
            // Register for GPS location updates
            try {
                if (null != mLocationManager
                        .getProvider(LocationManager.GPS_PROVIDER)) {
                    mLocationManager.requestLocationUpdates(
                            LocationManager.GPS_PROVIDER, POLLING_FREQ,
                            MIN_DISTANCE, mLocationListener);
                }
            }
            catch (SecurityException se)
            {
                se.printStackTrace();
            }
            // Schedule a runnable to unregister location listeners
            Executors.newScheduledThreadPool(1).schedule(new Runnable() {
                @Override
                public void run() {
                    Log.i(TAG, "location updates cancelled");
                    try {
                        mLocationManager.removeUpdates(mLocationListener);
                    } catch (SecurityException se) {
                        se.printStackTrace();
                    }
                }
            }, MEASURE_TIME, TimeUnit.MILLISECONDS);
        }
    }

    @Override
    public void onStop() {
        super.onStop();

        //Check device supported Accelerometer senssor or not
        if (AccelerometerManager.isListening()) {

            //Start Accelerometer Listening
            AccelerometerManager.stopListening();

        }

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i("Sensor", "Service  destroy");

        if (AccelerometerManager.isListening()) {


            AccelerometerManager.stopListening();


        }


    }

    public void onAccelerationChanged(float x, float y, float z) {
        // TODO Auto-generated method stub

    }


    public void onLocationChanged(Location location) {

        // Determine whether new location is better than current best
        // estimate
        if (null == mBestReading
                || location.getAccuracy() < mBestReading.getAccuracy()) {
            // Update best estimate
            mBestReading = location;
            // Update display
            updateDisplay(location);
            if (mBestReading.getAccuracy() < MIN_ACCURACY)
                try {
                    mLocationManager.removeUpdates(mLocationListener);
                }
                catch (SecurityException se){
                    se.printStackTrace();
                }
        }
    }

    protected void onPause() {
        super.onPause();
        try {
            mLocationManager.removeUpdates(mLocationListener);
        }
        catch (SecurityException se)
        {
            se.printStackTrace();
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[]
            grantResults) {
        switch (requestCode) {
            case 200: {
                if(grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // {Some Code}
                }
            }
        }
    }

    // Get the last known location from all providers
    // return best reading that is as accurate as minAccuracy and
    // was taken no longer then minAge milliseconds ago. If none,
    // return null.
    private Location bestLastKnownLocation(float minAccuracy, long maxAge) {
        Location bestResult = null;
        float bestAccuracy = Float.MAX_VALUE;
        long bestAge = Long.MIN_VALUE;
        List<String> matchingProviders = mLocationManager.getAllProviders();
        for (String provider : matchingProviders) {
            try {
                Location location = mLocationManager.getLastKnownLocation(provider);
                if (location != null) {
                    float accuracy = location.getAccuracy();
                    long time = location.getTime();
                    if (accuracy < bestAccuracy) {
                        bestResult = location;
                        bestAccuracy = accuracy;
                        bestAge = time;
                    }
                }
            }
            catch (SecurityException se)
            {
                se.printStackTrace();
            }
        }
        // Return best reading or null
        if (bestAccuracy > minAccuracy
                || (System.currentTimeMillis() - bestAge) > maxAge) {
            return null;
        } else {
            return bestResult;
        }
    }
    public void addListenerOnButton() {



        happy = (ImageButton) findViewById(R.id.happyB);
        sad = (ImageButton) findViewById(R.id.sadB);
        final TextView MText = (TextView)findViewById(R.id.MText2);


        sad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(new_entry.this,"Aww, what's wrong?" , Toast.LENGTH_SHORT).show();
                // Set TextView to Sad
                TextView MText = (TextView)findViewById(R.id.MText2);
                MText.setText("Sad");
                MText.setVisibility(View.INVISIBLE);

                // Change Sad image to Clicked
                sad.setImageResource(R.drawable.sadclicked);
                // Change happy image back to Unclicked
                happy.setImageResource(R.drawable.happyunclicked);
            }

        });

        happy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(new_entry.this, "You're Happy, yay!", Toast.LENGTH_SHORT).show();
                TextView MText = (TextView)findViewById(R.id.MText2);
                MText.setText("Happy");
                MText.setVisibility(View.INVISIBLE);
                // Change Happy image to Clicked
                happy.setImageResource(R.drawable.happyclicked);
                // Change Sad image back to Unclicked
                sad.setImageResource(R.drawable.sadunclicked);
            }

        });

    }
    // Update display
    private void updateDisplay(Location location) {

        latdbl = location.getLongitude();
        longdbl = location.getLatitude();
        latstr = String.valueOf(latdbl);
        longstr = String.valueOf(longdbl);
        locationinfo.setText("Location is " + latstr + longstr);




    }


}

