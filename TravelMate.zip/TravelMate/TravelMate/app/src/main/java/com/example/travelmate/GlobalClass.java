package com.example.travelmate;

import android.app.Application;

/**
 * Created by 40059110 on 18/04/2016.
 */
public class GlobalClass extends Application {

    private Boolean logged;

    public Boolean getLogged(){

        return logged;

    }
}
