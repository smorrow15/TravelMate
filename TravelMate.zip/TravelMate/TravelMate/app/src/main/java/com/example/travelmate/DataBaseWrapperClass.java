package com.example.travelmate;

/**
 * Created by 40059110 on 12/04/2016.
 */
public class DataBaseWrapperClass {
}
