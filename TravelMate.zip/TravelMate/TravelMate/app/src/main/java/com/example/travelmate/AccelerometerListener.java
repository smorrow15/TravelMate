package com.example.travelmate;

/**
 * Created by 40059110 on 12/04/2016.
 */
public interface AccelerometerListener {

    public void onAccelerationChanged(float x, float y, float z);


    public void onShake(float force);


}

