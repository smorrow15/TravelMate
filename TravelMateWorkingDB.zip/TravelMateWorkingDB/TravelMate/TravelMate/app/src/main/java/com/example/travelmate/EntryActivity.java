package com.example.travelmate;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by 40080429 on 14/04/2016.
 */
public class EntryActivity extends Activity {
    TextView entryTitle;
    TextView entry;
    Entry selectedEntry;
    EntrySQLiteHelper db;
//http://themasterworld.com/android-how-can-add-data-into-sqlite-database/
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entry);
        entryTitle = (TextView) findViewById(R.id.title);
        entry = (TextView) findViewById(R.id.entry);
        // get the intent that we have passed from AndroidDatabaseExample
        Intent intent = getIntent();
        int id = intent.getIntExtra("entry", -1);

        // open the database of the application context
        MyApplication mApplication = (MyApplication)getApplicationContext();
        db = mApplication.db;
        // read the entry with "id" from the database
        // call method from my_journals.java to get id

       //id=1;
        selectedEntry = db.readEntry(id);
        initializeViews();
    }
    public void initializeViews() {
        entryTitle.setText(selectedEntry.getEntryTitle());
        entry.setText(selectedEntry.getEntry());
    }
    public void update(View v) {
        Toast.makeText(getApplicationContext(), "This entry is updated.",
                Toast.LENGTH_SHORT).show();
        selectedEntry.setEntryTitle(((EditText)
                findViewById(R.id.titleEdit)).getText().toString());
        selectedEntry.setEntry(((EditText)
                findViewById(R.id.entryEdit)).getText().toString());
        // update
        db.updateEntry(selectedEntry);
        finish();
    }
    public void delete(View v) {
        Toast.makeText(getApplicationContext(), "This entry is deleted.",
                Toast.LENGTH_SHORT).show();
        // delete
        db.deleteEntry(selectedEntry);
        finish();
    }



}
