package com.example.travelmate;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ListActivity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.DatePicker;
import android.view.View.OnClickListener;
import com.example.travelmate.EntrySQLiteHelper;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
public class new_entry extends activity2 {

    private DatePicker datePicker;
    private Calendar calendar;
    private TextView dateView;
    private int year, month, day;
    private EditText title, entry;
    private Button SaveButton;
    EntrySQLiteHelper db;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_entry);


        title = (EditText) findViewById(R.id.etJourTitle);
        entry = (EditText) findViewById(R.id.etJourDescription);
        SaveButton = (Button) findViewById(R.id.save);
        dateView = (TextView) findViewById(R.id.datepickertext);
        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);

        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        showDate(year, month + 1, day);

        MyApplication mApplication = (MyApplication)getApplicationContext();
        db = mApplication.db;



    SaveButton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

           String entrytitle = title.getText().toString();
            String insertentry = entry.getText().toString();
            db.createEntry(entrytitle, insertentry);
            Toast.makeText(getApplicationContext(), "New entry successfully added", Toast.LENGTH_SHORT).show();
            /*Intent intent = new Intent(new_entry.this, my_journals.class);
            Bundle extras = new Bundle();
            intent.putExtra("EXTRATITLE", entrytitle);
           intent.putExtra("EXTRAENTRY", insertentry);
            startActivity(intent);*/
            db.close();
            List<Entry> list=db.getAllEntries();
        }
    }
    );
}
          //    String currentDateTimeString = DateFormat.getDateTimeInstance().format(new Date());

    // textView is the TextView view that should display it
    //      textView.setText(currentDateTimeString);
    @SuppressWarnings("deprecation")
    public void setDate(View view) {
        showDialog(999);
        Toast.makeText(getApplicationContext(), "ca", Toast.LENGTH_SHORT)
                .show();
    }

    // shows today's date
    private void showDate(int year, int month, int day) {
        dateView.setText(new StringBuilder().append(day).append("/")
                .append(month).append("/").append(year));
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 999) {
            return new DatePickerDialog(this, myDateListener, year, month, day);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker arg0, int arg1, int arg2, int arg3) {
            // TODO Auto-generated method stub
            // arg1 = year
            // arg2 = month
            // arg3 = day
            showDate(arg1, arg2+1, arg3);
        }
    };


    }