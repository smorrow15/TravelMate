package com.example.travelmate;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.EditText;

/**
 * Created by 40080429 on 14/04/2016.
 */
public class EntrySQLiteHelper extends SQLiteOpenHelper {
    private static final int database_VERSION = 3;
    // database name
    private static final String database_NAME = "EntryDB";
    private static final String table_ENTRY = "entry";
    private static final String entry_ID = "id";
    private static final String entry_TITLE = "entrytitle";
    private static final String entry_ENTRY = "entry";
    private static final String[] COLUMNS = { entry_ID, entry_TITLE, entry_ENTRY };

    public EntrySQLiteHelper(Context context) {
        super(context, database_NAME, null, database_VERSION);

    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL statement to create entry table
        String CREATE_ENTRY_TABLE = "CREATE TABLE entry ( " + "id INTEGER PRIMARY KEY AUTOINCREMENT, " + "entrytitle TEXT, " + "entry TEXT )";
        db.execSQL(CREATE_ENTRY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // drop entry table if already exists
        db.execSQL("DROP TABLE IF EXISTS entry");
        this.onCreate(db);
    }

    public void createEntry(String entrytitle, String entry) {
        // get reference of the EntryDB database

       SQLiteDatabase db = this.getWritableDatabase();

       ContentValues values = new ContentValues();
       values.put(entry_TITLE, entrytitle);
        values.put(entry_ENTRY, entry);
         //insert entry
       db.insert(table_ENTRY, null, values);
        // close database transaction
      db.close();


   }


    private Cursor getCursor (Cursor cursor){
            if (cursor != null){
                cursor.moveToFirst();
            }
         return cursor;
    }

    public Entry readEntry(int id) {
        // get reference of the EntryDB database
        SQLiteDatabase db = this.getReadableDatabase();
        // get entry query
        Cursor cursor = db.query(table_ENTRY, // a. table
                COLUMNS, " id = ?", new String[]{String.valueOf(id)}, null, null,
                null, null);
        if (cursor != null)
            cursor.moveToFirst();
        //Cursor cursorNew=getCursor(cursor);
        //String d=cursorNew.getString(cursorNew.getColumnIndex("entry"));
       Entry entry = new Entry();
        entry.setId(Integer.parseInt(cursor.getString(0)));
        entry.setEntryTitle(cursor.getString(1));
        entry.setEntry(cursor.getString(2));
       // entry.setEntryTitle(cursorNew.getString(cursorNew.getColumnIndex("entrytitle")));
        //entry.setEntry(cursorNew.getString(cursorNew.getColumnIndex("entry")));
        return entry;
    }
    public List getAllEntries() {
        List entries = new LinkedList();
        // select entry query
        String query = "SELECT * FROM " + table_ENTRY;
        // get reference of the EntryDB database
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        // parse all results
        Entry entry = null;
        if (cursor.moveToFirst()) {
            do {
                entry = new Entry();
                entry.setId(Integer.parseInt(cursor.getString(0)));
                entry.setEntryTitle(cursor.getString(1));
                entry.setEntry(cursor.getString(2));
                // Add book to books
                entries.add(entry);
            } while (cursor.moveToNext());
        }
        return entries;
    }
    public int updateEntry(Entry entry) {
        // get reference of the EntryDB database
        SQLiteDatabase db = this.getWritableDatabase();
        // make values to be inserted
        ContentValues values = new ContentValues();
        values.put("entrytitle", entry.getEntryTitle()); // get title
        values.put("entry", entry.getEntry()); // get author
        // update
        int i = db.update(table_ENTRY, values, entry_ID + " = ?", new String[] {
                String.valueOf(entry.getId()) });
        db.close();
        return i;
    }
    // Deleting single entry
    public void deleteEntry(Entry entry) {
        // get reference of the EntryDB database
        SQLiteDatabase db = this.getWritableDatabase();
        // delete book
        db.delete(table_ENTRY, entry_ID + " = ?", new String[] {
                String.valueOf(entry.getId()) });
        db.close();
    }


}

