package example.com.iamhere;
/**
 * Created by 40080429 on 14/04/2016.
 */
public class Entry {
    private int id;
    private String entrytitle;
    private String entry;
    private String date;
    private String mood;
    private String locationlat;
    private String locationlon;
    public Entry(){

    }

    public Entry(String entrytitle, String entry, String date, String mood, String locationlat, String locationlon) {
        super();
        this.entrytitle = entrytitle;
        this.entry = entry;
        this.date = date;
        this.mood = mood;
        this.locationlat = locationlat;
        this.locationlon = locationlon;
    }

    public long getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getEntryTitle() {
        return this.entrytitle;
    }
    public void setEntryTitle(String entrytitle) {
        this.entrytitle = entrytitle;
    }

    public String getEntry() {
        return this.entry;
    }
    public void setEntry(String entry) {
        this.entry = entry;
    }

    public String getEntryDate() { return this.date;}
    public void setEntryDate(String date) { this.date = date;}

    public String getEntryMood() { return this.mood;}
    public void setEntryMood(String mood) { this.mood = mood;
    }
    public String getEntryLocationLat() { return this.locationlat;}
    public void setEntryLocationLat(String locationlat) { this.locationlat = locationlat;
    }
    public String getEntryLocationLon() { return this.locationlon;}
    public void setEntryLocationLon(String locationlon) { this.locationlon = locationlon;
    }

    public String toString() {
        return "Entry [id=" + id + ", title=" + entrytitle + ", entry=" + entry + ", date=" + date + ", mood=" + mood + ", locationlat=" + locationlat
                + "]";
    }
}
