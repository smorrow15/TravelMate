package example.com.iamhere;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * Created by 40080429 on 14/04/2016.
 */
public class EntryActivity extends Activity {
    TextView date, mood;
    EditText entryTitle2, entry2;
    Entry selectedEntry;
    MyApplication mApplication;
    EntrySQLiteHelper db;
    public int id;
    ImageView moodImg;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        mApplication = (MyApplication)getApplicationContext();
        db = mApplication.db;

        setContentView(R.layout.activity_entry);

        date = (TextView) findViewById(R.id.displaydate);
        mood = (TextView) findViewById(R.id.displaymood);
        mood.setVisibility(View.INVISIBLE);
        moodImg = (ImageView) findViewById(R.id.moodImg);
        entryTitle2 = (EditText) findViewById(R.id.titleEdit);
        entry2 = (EditText) findViewById(R.id.entryEdit);
        // get the intent that we have passed from AndroidDatabaseExample

        String id2;
        Bundle extras = getIntent().getExtras();

        if(extras != null) {
            id2 = extras.getString("entry");
            id = Integer.parseInt(id2);

        }

        selectedEntry = db.readEntry(id);
        // calling initializeViews() function
        initializeViews();
        // calling checkMood() function
        // if contains letters py (Hap(py)); set image to happy
        // if else contains letters sa (S(ad)); set image to sad
        // else set image to neutral
        checkMood(moodImg,mood,"py", "sa");

    }
    public void initializeViews() {
        entryTitle2.setText(selectedEntry.getEntryTitle());
        entry2.setText(selectedEntry.getEntry());
        date.setText(selectedEntry.getEntryDate());
        mood.setText(selectedEntry.getEntryMood());

    }
    public void update(View v) {
        Toast.makeText(getApplicationContext(), "This entry is updated.",
                Toast.LENGTH_SHORT).show();
        selectedEntry.setEntryTitle(((EditText)
                findViewById(R.id.titleEdit)).getText().toString());
        selectedEntry.setEntry(((EditText)
                findViewById(R.id.entryEdit)).getText().toString());

        // update
        Intent intentmenu = new Intent(this, my_journals.class);
        startActivity(intentmenu);
        db.updateEntry(selectedEntry);
        finish();
    }
    public void delete(View v) {
        Toast.makeText(getApplicationContext(), "This entry is deleted.",
                Toast.LENGTH_SHORT).show();
        // delete
        Intent intentmenu = new Intent(this, my_journals.class);
        startActivity(intentmenu);
        db.deleteEntry(selectedEntry);
        finish();

    }

    public void checkMood(ImageView v, TextView t, String s, String r) {
        if (t.getText().toString().contains(s)) {
            //Log.v
            v.setImageResource(R.drawable.happyclicked);
        } else if (t.getText().toString().contains(r)) {
            v.setImageResource(R.drawable.sadclicked);
        } else {
            v.setImageResource(R.drawable.neutral);
        }
    }
}

