package example.com.iamhere;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class CustomAdapter extends BaseAdapter {

    String[] result;
    Context context;
    int[] imageId;

    TextView uName;
    //String sName;

    private static LayoutInflater inflater = null;

    public CustomAdapter(MainActivity activity2 , String[] menuList, int[] menuImgs) {
        result = menuList;
        context = activity2;
        imageId = menuImgs;

        inflater = (LayoutInflater) context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return result.length;
    }
    @Override
    public Object getItem(int position) {
        return position;
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    public class Holder {
        TextView tv;
        ImageView img;


    }

    @Override
    // create a new ImageView for each item referenced by the Adapter
    public View getView(final int position, View convertView, ViewGroup parent) {

        Holder holder = new Holder();

        View rowView;
        rowView = inflater.inflate(R.layout.menu, null);

        holder.tv = (TextView) rowView.findViewById(R.id.menuText);
        holder.img = (ImageView) rowView.findViewById(R.id.menuDisplay);

        holder.tv.setText(result[position]);
        holder.img.setImageResource(imageId[position]);

       final TextView uName = (TextView) rowView.findViewById(R.id.userNameDisplay);

        rowView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                switch (position) {
                    case 0:
                        myIntent(v, my_journals.class);
                        break;
                    case 1:
                            myIntent(v, new_entry.class);
                        break;
                    case 2:
                        myIntent(v, MapsActivity.class);
                        break;
                    case 3:
                        myIntent(v, settings.class);
                        break;
                }
            }
        });
        return rowView;
    }

    // go to Intent function
    public void myIntent( View v, Class c){
        Intent i = new Intent(v.getContext(), c);
        v.getContext().startActivity(i);
    }



    }


