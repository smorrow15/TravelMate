package example.com.iamhere;

import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {
 private GoogleMap mMap;
 private ArrayList<MyMarker> mMyMarkersArray = new ArrayList<MyMarker>();
 private HashMap<Marker, MyMarker> mMarkersHashMap;
 List<Entry> list;
 EntrySQLiteHelper db;
 public String date;
 @Override
 protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_maps);
         ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
         .getMapAsync(this);

         mMarkersHashMap = new HashMap<Marker, MyMarker>();
         //add coordinates to the HashMap
          MyApplication mApplication = (MyApplication)getApplicationContext();
          db = mApplication.db;

         list = db.getAllEntries();

        // for each entry in database
          for (int i = 0; i < db.getAllEntries().size(); i++) {
              // get data and store in string value using get functions
               String lat = list.get(i).getEntryLocationLat();
               String lon = list.get(i).getEntryLocationLon();
               String title = list.get(i).getEntryTitle();
               String icon = list.get(i).getEntryMood();
               date = list.get(i).getEntryDate();

                  // moods stored as strings
               String moodicon = "";
               String happy = "Happy";
               String sad = "Sad";

                       // if image displayed is happy, display happy icon
                       if (icon.equals(happy)){
                        moodicon="happy";
                       }
                       // if image displayed is sad, display sad icon
                       else if (icon.equals(sad)){
                        moodicon="sad";
                       }
                       // if image displayed is neutral, display neutral icon
                       else{
                        moodicon = "neutral";
                       }

               mMyMarkersArray.add(new MyMarker(title, moodicon,
                       Double.parseDouble(lon), Double.parseDouble(lat)));

          }
 }

 @Override
 public void onMapReady(GoogleMap googleMap) {
 mMap = googleMap;
 setUpMap();
 }

 private void setUpMap() {
 mMap.addMarker(new MarkerOptions().position(new LatLng(0, 0)).title("Marker"));
 try {
 mMap.setMyLocationEnabled(true);
 }
 catch(SecurityException e)
 {
 e.printStackTrace();
 }
 plotMarkers(mMyMarkersArray);
 }
 private void plotMarkers(ArrayList<MyMarker> markers)
 {
  // if anything in array
 if(markers.size() > 0)
 {
  // or each item in array
 for (MyMarker myMarker : markers)
 {
 // Create user marker with custom icon and other options
 MarkerOptions markerOption = new MarkerOptions().position(new
         // draw lat and long values
         LatLng(myMarker.getmLatitude(), myMarker.getmLongitude()));
//


markerOption.icon(BitmapDescriptorFactory.fromResource(R.drawable.currentlocation_icon));
 Marker currentMarker = mMap.addMarker(markerOption);
 mMarkersHashMap.put(currentMarker, myMarker);
 mMap.setInfoWindowAdapter(new MarkerInfoWindowAdapter());
 }
 }
 }

  private int manageMarkerIcon(String markerIcon)
  {
   if (markerIcon.equals("happy"))
    return R.drawable.happyclicked;
   else if(markerIcon.equals("sad"))
    return R.drawable.sadclicked;
   else
    return R.drawable.neutral;
  }


     public class MarkerInfoWindowAdapter implements GoogleMap.InfoWindowAdapter
     {
         public MarkerInfoWindowAdapter()

         {
         }
         @Override
         public View getInfoWindow(Marker marker)
         {
         return null;
         }

         @Override
         public View getInfoContents(Marker marker)
         {
                 View v = getLayoutInflater().inflate(R.layout.infowindow_layout, null);
                 MyMarker myMarker = mMarkersHashMap.get(marker);
                 ImageView markerIcon = (ImageView) v.findViewById(R.id.marker_icon);
                 TextView markerLabel = (TextView)v.findViewById(R.id.marker_label);
                 TextView anotherLabel = (TextView)v.findViewById(R.id.another_label);
                 markerIcon.setImageResource(manageMarkerIcon(myMarker.getmIcon()));
                 markerLabel.setText(myMarker.getmLabel());
                 anotherLabel.setText(date);
             return v;
         }
     }
}