package com.example.travelmate;

import android.app.Activity;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.TextView;

public class activity2 extends MainActivity {

    GridView menu;
    public static String[] menuList ={"My Journals", "New Journal Entry", "My Calendar", "Settings"};

    public static int[] menuImgs =
            {R.drawable.your_notes, R.drawable.new_entry, R.drawable.calendar, R.drawable.settings};

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2);
        TextView uName = (TextView) findViewById(R.id.userNameDisplay);
        String hiUser;
        Bundle extras = getIntent().getExtras();
        if (extras != null){
            hiUser = extras.getString("uName");
            uName.setText("Welcome " + hiUser);

        }

        menu = (GridView) findViewById(R.id.menuGrid);
        menu.setAdapter(new CustomAdapter(this, menuList, menuImgs));
    }

}
