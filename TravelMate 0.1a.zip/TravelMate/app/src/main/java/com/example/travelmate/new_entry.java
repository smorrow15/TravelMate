package com.example.travelmate;

import android.content.Intent;
import android.os.Bundle;

public class new_entry extends activity2{

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_entry);


    }




}
