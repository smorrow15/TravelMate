package com.example.travelmate;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 40059110 on 11/04/2016.
 */
public class operations extends new_entry {

    private DataBaseWrapperClass dbHelper;
    private String[] JOURNAL_TABLE_COLUMNS = { DataBaseWrapperClass.ENTRY_ID,
            DataBaseWrapperClass.ENTRY_TEXT };
    private SQLiteDatabase database;

    public operations(Context context) {
        dbHelper = new DataBaseWrapperClass(context);
    }
    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }
    public void close() {
        dbHelper.close();
    }

    public Entry addEntry(String entry) {
        ContentValues values = new ContentValues();
        values.put(DataBaseWrapperClass.ENTRY_TEXT, entry);
        long studId = database.insert(DataBaseWrapperClass.JOURNALS, null, values);
        // now that the student is created return it ...
        Cursor cursor = database.query(DataBaseWrapperClass.JOURNALS,
                JOURNAL_TABLE_COLUMNS, DataBaseWrapperClass.ENTRY_ID + " = "
                        + studId, null, null, null, null);
        cursor.moveToFirst();
        Entry newComment = parseEntry(cursor);
        cursor.close();
        return newComment;
    }

    public List getAllEntries() {
        List entries = new ArrayList();
        Cursor cursor = database.query(DataBaseWrapperClass.JOURNALS,
                JOURNAL_TABLE_COLUMNS, null, null, null, null, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Entry entry = parseEntry(cursor);
            entries.add(entry);
            cursor.moveToNext();
        }
        cursor.close();
        return entries;
    }

    private Entry parseEntry(Cursor cursor) {
        Entry student = new Entry();
        student.setId((cursor.getInt(0)));
        student.setEntry(cursor.getString(1));
        return student;
    }
}
