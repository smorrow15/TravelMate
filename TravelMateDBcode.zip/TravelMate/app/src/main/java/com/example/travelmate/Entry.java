package com.example.travelmate;

public class Entry {
    private int id;
    private String entry;
    public long getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getEntry() {
        return this.entry;
    }
    public void setEntry(String entry) {
        this.entry = entry;
    }
    @Override
    public String toString() {
        return entry;
    }
}