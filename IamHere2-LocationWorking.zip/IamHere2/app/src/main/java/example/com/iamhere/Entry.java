package example.com.iamhere;
/**
 * Created by 40080429 on 14/04/2016.
 */
public class Entry {
    private int id;
    private String entrytitle;
    private String entry;

public Entry(){

}

    public Entry(String entrytitle, String entry) {
        super();
        this.entrytitle = entrytitle;
        this.entry = entry;
    }

    public long getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getEntryTitle() {
        return this.entrytitle;
    }
    public void setEntryTitle(String entrytitle) {
        this.entrytitle = entrytitle;
    }

    public String getEntry() {
        return this.entry;
    }
    public void setEntry(String entry) {
        this.entry = entry;
    }


    public String toString() {
        return "Entry [id=" + id + ", title=" + entrytitle + ", entry=" + entry
                + "]";
    }
}
