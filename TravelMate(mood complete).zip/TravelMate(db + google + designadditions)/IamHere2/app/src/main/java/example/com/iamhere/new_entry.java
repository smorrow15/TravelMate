package example.com.iamhere;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.DatePicker;
import android.widget.RadioGroup;

import java.util.Calendar;
import java.util.List;


public class new_entry extends activity2 implements AccelerometerListener {


    private Calendar calendar;
    private TextView dateView, moodTextView;
    private int year, month, day;
    private EditText title, entry;
    private Button SaveButton;
    private SeekBar mood;
    private TextView MText;
    private RadioButton radioButton;
    private RadioGroup radioGroup;
    private RadioButton btnDisplay;
    private Button btnSave;
    private ImageButton happy, sad;



    EntrySQLiteHelper db;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_entry);



        title = (EditText) findViewById(R.id.etJourTitle);
        entry = (EditText) findViewById(R.id.etJourDescription);
        SaveButton = (Button) findViewById(R.id.save);
        dateView = (TextView) findViewById(R.id.datepickertext);
        MText = (TextView)findViewById(R.id.MText2);
        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);


        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        showDate(year, month + 1, day);



        addListenerOnButton();

        //     final String selectedR = btnDisplay.getText().toString();

        MyApplication mApplication = (MyApplication) getApplicationContext();
        db = mApplication.db;

        // Create method for EFFICIENCY
        SaveButton.setOnClickListener(new View.OnClickListener() {
                                          @Override
                                          public void onClick(View v) {

                                              String entrytitle = title.getText().toString();
                                              String insertentry = entry.getText().toString();
                                              String insertdate = dateView.getText().toString();
                                              String insertmood = MText.getText().toString();
                                              db.createEntry(entrytitle, insertentry, insertdate, insertmood);
                                              title.setText("");
                                              entry.setText("");
                                              Toast.makeText(getApplicationContext(), "New entry successfully added", Toast.LENGTH_SHORT).show();
                                              db.close();
                                              List<Entry> list = db.getAllEntries();
                                              Intent intentmenu = new Intent(new_entry.this, my_journals.class);
                                              startActivity(intentmenu);
                                          }
                                      }
        );

    }


    @SuppressWarnings("deprecation")
    public void setDate(View view) {
        showDialog(999);

    }


    // shows today's date
    private void showDate(int year, int month, int day) {
        dateView.setText(new StringBuilder().append(day).append("/")
                .append(month).append("/").append(year));
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 999) {
            return new DatePickerDialog(this, myDateListener, year, month, day);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker arg0, int arg1, int arg2, int arg3) {
            // TODO Auto-generated method stub
            // arg1 = year
            // arg2 = month
            // arg3 = day
            showDate(arg1, arg2 + 1, arg3);
        }
    };

    public void onShake(float force) {

        // Do your stuff here

        EditText clear = (EditText) findViewById(R.id.etJourDescription);
        clear.setText("");

        // Called When Motion Detected


    }

    @Override
    public void onResume() {
        super.onResume();


        //Check device supported Accelerometer senssor or not
        if (AccelerometerManager.isSupported(this)) {

            //Start Accelerometer Listening
            AccelerometerManager.startListening(this);
        }
    }

    @Override
    public void onStop() {
        super.onStop();

        //Check device supported Accelerometer senssor or not
        if (AccelerometerManager.isListening()) {

            //Start Accelerometer Listening
            AccelerometerManager.stopListening();

        }

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i("Sensor", "Service  destroy");

        //Check device supported Accelerometer senssor or not
        if (AccelerometerManager.isListening()) {

            //Start Accelerometer Listening
            AccelerometerManager.stopListening();


        }

    }

    public void onAccelerationChanged(float x, float y, float z) {
        // TODO Auto-generated method stub

    }

    public void addListenerOnButton() {

     //   radioGroup = (RadioGroup) findViewById(R.id.radio_mood);
        btnSave = (Button) findViewById(R.id.location);
         happy = (ImageButton) findViewById(R.id.happyB);
         sad = (ImageButton) findViewById(R.id.sadB);
        final TextView MText = (TextView)findViewById(R.id.MText2);


        sad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(new_entry.this,"Aww, what's wrong?" , Toast.LENGTH_SHORT).show();
                // Set TextView to Sad
                TextView MText = (TextView)findViewById(R.id.MText2);
                MText.setText("Sad");
                MText.setVisibility(View.INVISIBLE);
                // Change Sad image to Clicked
                sad.setImageResource(R.drawable.sadclicked);
                // Change happy image back to Unclicked
                happy.setImageResource(R.drawable.happyunclicked);
            }

        });

        happy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(new_entry.this, "You're Happy, yay!", Toast.LENGTH_SHORT).show();
                TextView MText = (TextView)findViewById(R.id.MText2);
                MText.setText("Happy");
                MText.setVisibility(View.INVISIBLE);
                // Change Happy image to Clicked
                happy.setImageResource(R.drawable.happyclicked);
                // Change Sad image back to Unclicked
                sad.setImageResource(R.drawable.sadunclicked);
            }

        });

    }
}
